# Updated Information
For a more readable version and updated informations, we refer the user to the website: [https://heplib.github.io](https://heplib.github.io)


# HepLib Directory
1. `src` contains all source code of `HepLib` (_NOT_ including the required `external` `libraries` and `programs`). To build the `HepLib` library, please check the details at following [**Installation**](#Installation @method 1) section.

2. `codes` contains the `.cpp` files that provide complete contents which are used in this paper.

3. `examples` contains some typical examples, including

    * `Basic`: the `.cpp` files in this folder provide some basic usages of the functions extended to `GiNaC` itself, or interfaces to `Fermat` or `FORM`.

    * `FC`: the `.cpp` files in this folder provide some usages of the basic objects familiar to the researcher in `High Energy Physics`, especially to `FeynCalc` users, including a complete example using `Qgraf`, demonstration of using form to evaluate Dirac-γ or `SUNT` traces, `TIR` for tensor index reduction, IBP reductions with `FIRE` and so on.

    * `SD`: the `.cpp` files in this folder provide some basic usages of sector decomposition method, including numerical evaluation of loop integrals or general parametric integration using `SecDec` class.

      
# Usage of Examples

One can compile the `.cpp` file to a executable program with the help of `heplib++`, we take the `trace.cpp` which is located in the directory `codes` for example:

1. change the current working directory to codes by commands: `cd codes`

2. build the `trace.cpp` to an executable program `trace` by commands: `<INSTALL PATH>/bin/heplib++ -o trace trace.cpp`

3. run the `trace` program by commands: `./trace`

4. one will see the output like: `8*p2.p1+(-4)*D*p2.p1`

5. one can try other examples by repeat the step `1` to `4`.

   


# Installation @method 1

To install the library, one needs the GNU compiler (`gcc7` to `gcc10` have been tested) and `cmake` (v3.15 or later).

The simplest way to install all required `external library` and `programs`, including the `HepLib` itself, is to use the install script `install.sh`, and one can type the following commands in the terminal:

```bash
wget https://heplib.github.io/install.sh
chmod +x install.sh
INSTALL_PATH=<INSTALL PATH> jn=16 ./install.sh
```

where the `<INSTALL PATH>` is the path for the libraries to be installed to, and `jn` is the number of jobs used in invoking `make -j $jn` in the script.

the detailed information about the installation can found in the file `log.txt`, if everything goes well, one can check the `HepLib/codes` following the instructions listed in the section: [Usage of Examples](#Usage of Examples).


# Installation @method 2
Similar to the [method 1](#Installation @method 1), one can also use the install `makefile` to install all required `external library` and `programs`, including the `HepLib` itself, and one can type the following commands in the terminal:

```bash
wget https://heplib.github.io/makefile
make INSTALL_PATH=<INSTALL PATH> jn=16
```

where the `<INSTALL PATH>` is the path for the libraries to be installed to, and `jn` is the number of jobs used in invoking `make -j $jn` in the script.

the detailed information about the installation can found at the `log.txt`.


# Installation Manually


Assuming one has exported the environment variable `INSTALL_PATH`:

```bash
export INSTALL_PATH="<INSTALL PATH>"
```

## 1. Install External libraries:

1. `GMP` download and install `GMP(v6.2.1)` by typing the following commands in the terminal:

```bash
curl -L -O https://gmplib.org/download/gmp/gmp-6.2.1.tar.bz2
tar jxf gmp-6.2.1.tar.bz2
cd gmp-6.2.1
./configure --prefix=$INSTALL_PATH
make -j 16
make install
```

2. `MPFR` download and install `MPFR(v4.0.2)` by typing the following commands in the terminal:

```bash
curl -L -O https://heplib.github.io/download/mpfr-4.0.2.tar.gz
tar zxf mpfr-4.0.2.tar.gz
cd mpfr-4.0.2
./configure --prefix=$INSTALL_PATH --with-gmp=<INSTALL PATH> --enable-float128 --enable-thread-safe
make -j 16
make install
```

3. `CLN` download and install `CLN(v1.3.6)` by typing the following commands in the terminal:

```bash
curl -L -O https://www.ginac.de/CLN/cln-1.3.6.tar.bz2
tar jxf cln-1.3.6.tar.bz2
cd cln-1.3.6
./configure --prefix=$INSTALL_PATH --with-gmp=$INSTALL_PATH
make -j 16
make install
```

4. `GiNaC` download and install `GiNaC(v1.8.0)` by typing the following commands in the terminal:

```bash
curl -L -O https://www.ginac.de/ginac-1.8.0.tar.bz2
cd ginac-1.8.0
./configure --prefix=$INSTALL_PATH PKG_CONFIG_PATH=$INSTALL_PATH/lib/pkgconfig
make -j 16
make install
```

5. `CUBA` download and install `CUBA(v4.2)` by typing the following commands in the terminal:

```bash
curl -L -O http://www.feynarts.de/cuba/Cuba-4.2.tar.gz
tar zxf Cuba-4.2.tar.gz
cd Cuba-4.2
./configure --prefix=$INSTALL_PATH --with-real=16 CFLAGS="-fPIC -fcommon" CXXFLAGS="-fPIC -fcommon"
make
make install
```

6. `MinUit2` download and install `MinUit2(v5.34.14)` by typing the following commands in the terminal:

```bash
curl -L -O http://project-mathlibs.web.cern.ch/project-mathlibs/sw/5_34_14/Minuit2/Minuit2-5.34.14.tar.gz
cd Minuit2-5.34.14
./configure --prefix=$INSTALL_PATH
make -j 16
make install
```

7. `QHull` download and install `QHull(v2020.2)` by typing the following commands in the terminal:

```bash
curl -L -O http://www.qhull.org/download/qhull-2020.2.zip
unzip -q qhull-2020.2.zip
cd qhull-2020.2
cp Makefile Makefile.bak
cat Makefile.bak | sed "s/\/usr\/local/\$\$INSTALL_PATH/g" > Makefile
make
make install
```
### 2. Install External Binary Programs:

1. `Fermat` download and install `Fermat` by typing the following commands in the terminal:

```bash
#for Linux OS
curl -L -O http://home.bway.net/lewis/fermat64/ferl6.tar.gz
tar zxf ferl6.tar.gz
mv ferl6 $INSTALL_PATH
cd <INSTALL PATH>/bin
ln -s -f ../ferl6/fer64 .
```

```bash
#for Mac OS
curl -L -O http://home.bway.net/lewis/fermat64/ferlm.tar.gz
tar zxf ferm6.tar.gz
mv ferm6 $INSTALL_PATH
ln -s -f ../ferl6/fer64 .
```

2. `Form` download and install `Form` by typing the following commands in the terminal: 

```bash
# for Linux OS
curl -L -O https://github.com/vermaseren/form/releases/download/v4.2.1/form-4.2.1-x86_64-linux.tar.gz
tar zxf form-4.2.1-x86_64-linux.tar.gz
cp -rf form-4.2.1-x86_64-linux/form $INSTALL_PATH/bin/
cp -rf form-4.2.1-x86_64-linux/tform $INSTALL_PATH/bin/
```

```bash
# for Mac OS
curl -L -O https://github.com/vermaseren/form/releases/download/v4.2.1/form-4.2.1-x86_64-osx.tar.gz
tar zxf form-4.2.1-x86_64-osx.tar.gz
cp -rf form-4.2.1-x86_64-osx/form $INSTALL_PATH/bin/
cp -rf form-4.2.1-x86_64-osx/tform $INSTALL_PATH/bin/    
```

3. `FIRE` download and install `FIRE` by typing the following commands in the terminal:

```bash
git clone https://bitbucket.org/feynmanIntegrals/fire.git
mv fire/FIRE6 $INSTALL_PATH/FIRE6
rm -rf fire
cd $INSTALL_PATH/FIRE6
./configure --enable_zlib --enable_snappy --enable_lthreads --enable_tcmalloc --enable_zstd
make -j 16
make
```

3. `KIRA` download and install `KIRA` by typing the following commands in the terminal:

```bash
# for Linux OS
curl -L -o kira https://kira.hepforge.org/downloads?f=binaries/kira-2.0
chmod +x kira
mv -f kira $INSTALL_PATH/bin/kira
```

### 3. Compilation/Installation of HepLib

Changing the working directory to `HepLib/src`, and typing the following commands in the terminal:

```bash
cd HepLib/src
mkdir build && cd build
cmake -DCMAKE_INSTALL_PREFIX=$INSTALL_PATH ..
make -j 8 && make install
```


### 4. Check

Changing the working directory to `HepLib/codes`, and typing the following commands in the terminal:

```bash
<INSTALL PATH>/bin/heplib++ -o trace trace.cpp
./trace
```


