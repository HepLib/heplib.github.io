.. HepLib documentation master file, created by
   sphinx-quickstart on Sun Nov  1 11:42:49 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to HepLib's documentation!
==================================

.. toctree::
   :maxdepth: 2
   
   api/class
   api/function



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
