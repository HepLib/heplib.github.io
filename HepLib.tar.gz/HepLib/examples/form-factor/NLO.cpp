#include "HepLib.h"

using namespace std;
using namespace GiNaC;
using namespace HepLib;
using namespace FC;
using namespace Qgraf;
using namespace Quarkonium;

Vector p("p"), q1("q1"), q2("q2");
Symbol m("m");
ex p1 = p, p2 = p;

void TeXOut(const ex & e) {
    string o = ex2str(exfactor(fermat_normal(e)));
    string_replace_all(o,"𝛾","(-@$\\gamma$@-)");
    string_replace_all(o,"𝕚","(-@$\\mathbbm{1}$@-)");
    cout << o << endl << endl;
}

int main() {
    Verbose = 100;
    ex amps = garRead("amps.gar");
    Index mu("mu"), nu("nu");
    
    letSP(p)=m*m;
    letSP(p,nu)=0;
    
    lst extps = lst{ p };
    lst loops = lst{ q1 };
    ex proj = SpinProj(IO::In, 1, p1, p2, m, m, nu, -1, -3) * ColorProj(-1, -3);
    
    auto amp = amps.op(1).op(0);
    TeXOut(amp);
    
    amp = MatrixContract(amp);
    TeXOut(amp);
    
    amp = amp.subs(LI(-2)==mu);
    amp = amp * proj;
    amp = MatrixContract(amp);
    TeXOut(amp);

    form_using_su3 = true;
    amp = form(amp);
    amp = amp.subs(lst{NF==3,D==4-2*ep});
    TeXOut(amp);

    amp = TIR(amp, loops, extps);
    amp = amp.subs(lst{NF==3,D==4-2*ep});
    TeXOut(amp);
    return 0;

    // NLO
    loops = lst{ q1 };
    
    exvector res_vec;
    res_vec.push_back(amp);
    ApartIBP(1, res_vec, lst{ loops, extps });
    ex Res1 = 0;
    for(auto item : res_vec) Res1 += item.subs(lst{d==4-2*ep,D==4-2*ep});
    Res1 = fermat_normal(Res1);
    Res1 = mma_collect_lst(Res1,F(w1,w2));
    cout << "Result @NLO:" << endl;
    cout << Res1 << endl;
    cout << endl;
    
    return 0;
}
