#include "HepLib.h"

using namespace std;
using namespace GiNaC;
using namespace HepLib;
using namespace FC;
using namespace Qgraf;
using namespace Quarkonium;

Vector p("p"), q1("q1"), q2("q2");
Symbol m("m");
ex p1 = p, p2 = p;

void TeXOut(const ex & e) {
    ex ee = exfactor(fermat_normal(e));
    stringstream ss;
    HepFormat ho(ss);
cout << ee << endl << endl;
hout << endl << endl << endl;
    ho << ee;
    string o = ss.str();
    string_replace_all(o,"𝛾","(-@$\\gamma$@-)");
    string_replace_all(o,"𝕚","(-@$\\mathbbm{1}$@-)");
    cout << o << endl << endl;
}

int main() {
    Verbose = 100;
    ex amps = garRead("amps.gar");
    Index mu("mu"), nu("nu");
    
    letSP(p)=m*m;
    letSP(p,nu)=0;
    
    lst extps = lst{ p };
    lst loops = lst{ q1 };
    ex proj = SpinProj(IO::In, 1, p1, p2, m, m, nu, -1, -3) * ColorProj(-1, -3);
    
    auto amp1 = amps.op(1).op(0);
    //TeXOut(amp1);
    
    amp1 = MatrixContract(amp1);
    //TeXOut(amp1);
    
    amp1 = amp1.subs(LI(-2)==mu);
    amp1 = amp1 * proj;
    amp1 = MatrixContract(amp1);
    TeXOut(amp1);

    form_using_su3 = true;
    amp1 = form(amp1);
    amp1 = amp1.subs(lst{NF==3,D==4-2*ep});
    //TeXOut(amp);

    amp1 = TIR(amp1, loops, extps);
    amp1 = amp1.subs(lst{NF==3,D==4-2*ep});
    //TeXOut(amp);
    
    exvector res_vec;
    res_vec.push_back(amp1);
    ApartIBP(1, res_vec, lst{ loops, extps });
    ex res = 0;
    for(auto item : res_vec) res += item.subs(lst{d==4-2*ep,D==4-2*ep});
    res = fermat_normal(res);
    ex mi = str2ex("F({2*q1*p-q1^2},{1})"); // copied from last output
    ex miv = tgamma(-1+ep)*pow(m*m,1-ep)*pow(2*Pi,2*ep-4);
	res = res.subs(lst{ mi==miv });
	res = mma_series(res,ep,0);

    cout << res << endl;
    
    return 0;
}
