#include "HepLib.h"

using namespace std;
using namespace GiNaC;
using namespace HepLib;
using namespace FC;
using namespace Qgraf;
using namespace Quarkonium;

Vector p("p"), q1("q1"), q2("q2");
Symbol m("m");
ex p1 = p, p2 = p;

ex Amps();
int main() {
    Verbose = 100;
    
    ex amps;
    if(file_exists("amps.gar")) {
        amps = garRead("amps.gar");
    } else {
        amps = Amps();
        garWrite("amps.gar", amps);
    }

    Index mu("mu"), nu("nu");
    
    letSP(p)=m*m;
    letSP(p,nu)=0;
    
    lst extps = lst{ p };
    lst loops = lst{  };
    ex proj = SpinProj(IO::In, 1, p1, p2, m, m, nu, -1, -3) * ColorProj(-1, -3);
    ex ampN;

    auto DoFA = [&loops,&ampN,proj,mu,extps](int idx)->ex {
        ex amp = ampN.op(idx);
        amp = amp.subs(LI(-2)==mu);
        amp = amp * proj;
        amp = MatrixContract(amp);
        form_using_su3 = true;
        amp = form(amp);
        amp = amp.subs(lst{NF==3,D==4-2*ep});
        if(loops.nops()<1) return amp;
        amp = TIR(amp, loops, extps);
        amp = fermat_normal(amp);
        amp = Apart(amp,loops,extps);
        return amp;
    };
    
    // LO
    ampN = amps.op(0);
    loops = lst{ };
    auto res_vec = GiNaC_Parallel(ampN.nops(), DoFA, "LO");
    ex Res0 = 0;
    for(auto item : res_vec) Res0 += item.subs(lst{d==4-2*ep,D==4-2*ep});
    cout << "Result @LO:" << endl;
    cout << Res0 << endl;
    cout << endl;
    
    // NLO
    ampN = amps.op(1);
    loops = lst{ q1 };
    res_vec = GiNaC_Parallel(ampN.nops(), DoFA, "NLO");
    ApartIBP(1, res_vec, lst{loops,extps});
    ex Res1 = 0;
    for(auto item : res_vec) Res1 += item.subs(lst{d==4-2*ep,D==4-2*ep});
    Res1 = fermat_normal(Res1);
    Res1 = mma_collect_lst(Res1,F(w1,w2));
    cout << "Result @NLO:" << endl;
    cout << Res1 << endl;
    cout << endl;
    
sort_nmap[SP(q1)] = 1/ex(21);
sort_nmap[SP(q2)] = 1/ex(31);
sort_nmap[SP(q1,p)] = 1/ex(41);
sort_nmap[SP(q2,p)] = 1/ex(51);
sort_nmap[SP(q1,q2)] = 1/ex(61);
sort_nmap[m] = 1/ex(71);
sort_nmap[D] = 1/ex(81);
sort_nmap[gs] = 1/ex(91);
sort_nmap[ep] = 1/ex(101);
sort_nmap[SP(mu,nu)] = 1/ex(111);
    
    // NNLO
    ampN = amps.op(2);
//ampN = lst{ampN.op(15)};
    loops = lst{ q1, q2 };
    res_vec = GiNaC_Parallel(ampN.nops(), DoFA, "NNLO");
    ApartIBP(1, res_vec, lst{loops,extps});
    ex Res2 = 0;
    for(auto item : res_vec) Res2 += item.subs(lst{d==4-2*ep,D==4-2*ep});
    Res2 = mma_collect_lst(Res2,F(w1,w2));
    Res2 = fermat_normal(Res2);
    cout << "Result @NNLO:" << endl;
    cout << Res2.nops() << endl;
    cout << endl;
    return 0;
}


extern string model;
ex Amps() {
    
    Symbol A("A"), Q("Q"), Qbar("Qbar"), q("q"), qbar("qbar"), g("g"), gh("gh"), ghbar("ghbar");
    
    Qgraf::Process proc;
    proc.Model = model;
    proc.In = "Q[p1],Qbar[p2]";
    proc.Out = "A[pA]";
    proc.Options = "onshell";
    proc.LoopPrefix = "q";
    
    symtab st;
    st["pA"] = p1+p2;
    st["p1"] = p1;
    st["p2"] = p2;
    st["q1"] = q1;
    st["q2"] = q2;
    
    proc.Loops = 0;
    auto amp0 = proc.Amplitudes(st);
    proc.Loops = 1;
    auto amp1 = proc.Amplitudes(st);
    proc.Loops = 2;
    auto amp2 = proc.Amplitudes(st);
    
    lst glst;
    lst chk = lst{-1,-3,g};
    chk.sort();
    
    auto filter = [&](lst & ampi)->void {
        auto tmp = ampi;
        ampi.remove_all();
        for(auto amp : tmp) {
            
            auto cps = ShrinkCut(amp, lst{g, g}, 1);
            for(auto cpi : cps) {
                for(auto cpii0 : cpi) {
                    lst cpii = ex_to<lst>(cpii0.subs(lst{-10==g}));
                    cpii.sort();
                    if(cpii==chk) goto amp_done;
                }
            }
            
            ampi.append(amp);
            amp_done: ;
        }
    };
        
    lst amps = lst{ amp0, amp1, amp2 };
    cout << "Process Filter: [ ";
    for(auto amp : amps) cout << amp.nops() << " ";
    cout << "] :> ";
    
    filter(amp0);
    filter(amp1);
    filter(amp2);
    
    amps = lst{ amp0, amp1, amp2 };
    cout << "[ ";
    for(auto amp : amps) cout << amp.nops() << " ";
    cout << "]" << endl;
    
    // generate diagrams to pdf
    if(true) {
        LineTeX[A] = "photon";
        InOutTeX[-1]="$Q$";
        InOutTeX[-3]="$\\bar{Q}$";
        InOutTeX[-2]="$\\gamma^*$";
        DrawPDF(amp0, "amp0.pdf");
        DrawPDF(amp1, "amp1.pdf");
        DrawPDF(amp2, "amp2.pdf");
    }

    // feynman rules here
    auto map = MapFunction([&](const ex &e, MapFunction &self)->ex {
        if(isFunction(e,"OutField") || isFunction(e,"InField")) return 1;
        else if(isFunction(e, "Propagator")) {
            if(e.op(0).op(0)==q) {
                return QuarkPropagator(e, 0);
            } else if(e.op(0).op(0)==Q) {
                return QuarkPropagator(e, m);
            } else if(e.op(0).op(0)==g) {
                return GluonPropagator(e);
            } else if(e.op(0).op(0)==gh) {
                return GhostPropagator(e);
            }
        } else if(isFunction(e, "Vertex")) {
            if(e.nops()==3 && e.op(0).op(0)==ghbar && e.op(1).op(0)==gh) {
                // ghbar-gh-g
                return gh2gVertex(e);
            } else if(e.nops()==3 && e.op(0).op(0)==g && e.op(1).op(0)==g && e.op(2).op(0)==g) {
                // g^3
                return g3Vertex(e);
            } else if(e.nops()==4 && e.op(0).op(0)==g && e.op(1).op(0)==g && e.op(2).op(0)==g && e.op(3).op(0)==g) {
                // g^4
                return g4Vertex(e);
            } else if(e.nops()==3 && ((e.op(0).op(0)==qbar && e.op(1).op(0)==q) || (e.op(0).op(0)==Qbar && e.op(1).op(0)==Q)) ) {
                // qbar-q-g or Qbar-Q-g or g -> e
                if(e.op(2).op(0)==g) return q2gVertex(e);
                else {
                    auto fi1 = e.op(0).op(1);
                    auto fi2 = e.op(1).op(1);
                    auto fi3 = e.op(2).op(1);
                    return Matrix(GAS(LI(fi3)),DI(fi1),DI(fi2)) * SP(TI(fi1),TI(fi2));
                }
            }
        }
        return e.map(self);
    });

    amp0 = ex_to<lst>(map(amp0));
    amp1 = ex_to<lst>(map(amp1));
    amp2 = ex_to<lst>(map(amp2));
    
    return lst { amp0, amp1, amp2 };
}

std::string model = R"EOF(
[ model = 'eqcd Model' ]
%------------------------------------
% Propagators
%------------------------------------
[q, qbar, -]
[Q, Qbar, -]
[gh, ghbar, -]
[g, g, +, notadpole]
[A, A, +, external]
%------------------------------------
% Vertices
%------------------------------------
[qbar, q, g; QCD='+1']
[Qbar, Q, g; QCD='+1']
[g, g, g, g; QCD='+2']
[g, g, g; QCD='+1']
[ghbar, gh, g; QCD='+1']
[qbar, q, A; QCD='+0']
[Qbar, Q, A; QCD='+0']
)EOF";
