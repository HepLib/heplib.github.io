#include "HepLib.h"
using namespace HepLib;
using namespace FC;
using namespace Qgraf;

int main(int argc, char** argv) {
    Symbol m("m"), s("s");
    #define Prop(p) ((GAS(p)+m*GAS(1))/(SP(p)-m*m))
    Index i1("i1"), i2("i2"), i3("i3");
    Vector p3("p3"), p4("p4"), q1("q1"), q2("q2");
    letSP(p3)=m*m; 
    letSP(p4)=0; 
    letSP(p3,p4)=s;
    ex expr = TR(GAS(i1)*Prop(p3-q2)*GAS(i2)*Prop(q2)*GAS(i3)*Prop(p4+q2)*GAS(i1)*Prop(p3- q2)*GAS(i2)*Prop(q2)*GAS(i3)*Prop(p4+q2));
    expr = form(expr);
    cout << expr.normal() << endl;
    
    return 0;
}
