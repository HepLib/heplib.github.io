#include "HepLib.h"
using namespace HepLib;
using namespace SD;
int main(int argc, char** argv) {
    Symbol k("k"),r("r"),q("q"),p1("p1"),p2("p2"),s("s"); 
    FeynmanParameter fp;
    fp.LoopMomenta = lst{k,r,q};
    fp.Propagators= lst { -pow(k,2),-pow(k+p1+p2,2),-pow(-k+r,2),-pow(p1+r,2),-pow(k-q,2),-pow(p1+q,2)};
    fp.Exponents = lst{1+3*ep,1,1,1,1,1};
    fp.lReplacements[p1*p1] = 0;
    fp.lReplacements[p2*p2] = 0;
    fp.lReplacements[p2*p1] = s/2;
    fp.lReplacements[s] = -1;
    fp.Prefactor = pow(I*pow(Pi,2-ep),-3) * pow(tgamma(1-ep),3); 
    SecDec work;
    Verbose = 2;
    work.Evaluate(fp);
    cout << work.VEResult() << endl; 
    return 0;
}
