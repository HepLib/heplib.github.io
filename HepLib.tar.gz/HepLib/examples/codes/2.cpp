#include "HepLib.h"
using namespace HepLib;
using namespace FC;
int main(int argc, char** argv) {
    Symbol x("x"), y("y");
    ex expr = str2ex("x^4+x^3+x^2+x");
    MapFunction map([&](const ex &e, MapFunction self)->ex {
        if(e.match(pow(x,w)) && e.op(1).info(info_flags::even)) return pow(y,e.op(1)+2);
        else return e.map(self); 
    });
    ex expr2 = map(expr);
    cout << expr2 << endl; 
    return 0;
}
