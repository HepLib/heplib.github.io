#include "HepLib.h"
using namespace HepLib;
using namespace FC;
int main(int argc, char** argv) {
    Symbol a("a"), n("n");
    Parser parser;
    string expr_str = "WF(1)+x(1)^2+sin(5)+power(a,n)"; 
    ex expr = parser.Read(expr_str);
    cout << expr << endl; 
    return 0;
}
