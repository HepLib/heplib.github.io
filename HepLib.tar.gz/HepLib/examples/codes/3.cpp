#include "HepLib.h"
using namespace HepLib;
using namespace FC;
using namespace Qgraf;

int main(int argc, char** argv) {
    #define iCA Index::Type::CA
    #define iCF Index::Type::CF
    Symbol c1("c1"), c2("c2"); // varibles c1 and c2
    Index mu("mu"), nu("nu"); // Lorentz index μ and ν with index dimension D
    Index i("i",iCF), j("j",iCF);
    Index a("a",iCA), b("b",iCA), c("c",iCA);
    Vector p1("p1"), p2("p2"); // vector p1 and p2
    
    ex e1=SP(p1,p2);
    cout << "e1 = " << e1 << endl;
    
    ex e2=SP(p1,mu); 
    cout << "e2 = " << e2 << endl;
    ex e3=SUNT(i,j,a);
    cout << "e3 = " << e3 << endl;
    ex e4=SUNF(a,b,c);
    cout << "e4 = " << e4 << endl;
    ex e5=GAS(p1);
    cout << "e5 = " << e5 << endl;
    ex e6=GAS(mu); 
    cout << "e6 = " << e6 << endl;
    ex e7=SP(c1*p1+c2*p2); 
    cout << "e7 = " << e7 << endl;
    ex e8=GAS(c1*p1+c2*p2); 
    cout << "e8 = " << e8 << endl;
    ex e9=TR(GAS(p1)*GAS(mu)*GAS(p2)*GAS(nu)); 
    cout << "e9 = " << e9 << endl;
    Symbol i1("i1"), i2("i2"), i3("i3"), i4("i4"); 
    ex e10=Matrix(GAS(p1),i1,i2); 
    cout << "e10 = " << e10 << endl;
    ex e11=Matrix(GAS(p1),i1,i2) * Matrix(GAS(mu),i3,i1); 
    cout << "e11 = " << e11 << endl;
    ex e12=MatrixContract(e11);
    cout << "e12 = " << e12 << endl;
    
    return 0;
}
