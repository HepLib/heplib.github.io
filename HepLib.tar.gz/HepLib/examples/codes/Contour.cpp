#include "SD.h"
#include "cln/cln.h"

using namespace std;
using namespace GiNaC;
using namespace HepLib;
using namespace HepLib::SD;

int main() {
    
    XIntegrand xint;
    xint.Functions = lst{1,-4*x(4)*x(4)-12*x(1)*x(4)+x(1)*x(2),x(1),x(2)};
    xint.Exponents = lst{1,1/ex(2)-2*ep,3*ep-5/ex(2),ep-3/ex(2)};
    xint.Deltas = lst{lst{x(1),x(2),x(4)}};
    
    SecDec work;
    work.epN = 1;
    Verbose = 100;
    
    work.Initialize(xint);
    work.RemoveDeltas();
    work.SDPrepares();
    work.EpsEpExpands();
    work.CIPrepares();
    
    work.Contours();
    
    work.EpsAbs = 1E-5;
    work.RunPTS = 1000000;
    work.RunMAX = 5;
                
    auto intor = new HCubature();
    intor->MPXLimit = 1E-5;
    intor->QXLimit = 1E-2;
    work.Integrator = intor;
    work.Integrates();
    
    cout << VEResult(work.ResultError) << endl;
    
    
    return 0;
}
