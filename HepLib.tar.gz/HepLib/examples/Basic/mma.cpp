#include "HepLib.h"

using namespace HepLib;

int main() {

    Symbol a("a"), b("b"), m("m"), s("s"); 

    ex num = pow(a+b,4) * pow(a*b+s+m,4);
    ex den = (a+b+s)*(a+s*b);
    ex nd = num / den;

    hout << num << endl;
    auto ex_num = num.expand();
    cout << "collect w.r.t. {a,b}:" << endl;
    hout << mma_collect(ex_num, lst{a,b}, true, true) << endl;
    cout << "check: 0 = " << normal(num-ex_num.subs(lst{coCF(w)==w,coVF(w)==w})) << endl;
    cout << endl;
    
    hout << nd << endl;
    auto ex_s3 = mma_series(nd,s,3);
    hout << "series up to O(s^3):" << endl;
    hout << ex_s3 << endl;
    cout << endl;

}

