#include "HepLib.h"

using namespace HepLib;

int main() {

    Symbol a("a"), b("b"), m("m"), s("s"); 

    ex num = pow(a+b,4) * pow(a*b+s+m,4);
    ex den = (a+b+s)*(a+s*b);
    ex nd = num / den;

    hout << num << endl;
    auto ex_num = num.expand();
    cout << "collect w.r.t. {a,b}:" << endl;
    hout << collect_ex(ex_num, lst{a,b}, true, true) << endl;
    cout << "check: 0 = " << normal(num-ex_num.subs(lst{coCF(w)==w,coVF(w)==w})) << endl;
    cout << endl;
    
    hout << nd << endl;
    auto ex_s3 = series_ex(nd,s,3);
    ex_s3 = collect_ex(nd,lst{s},false,false,1);
    hout << "series up to O(s^3):" << endl;
    hout << ex_s3 << endl;
    cout << endl;

}

