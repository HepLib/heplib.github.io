#include "HepLib.h"

using namespace HepLib;

int main(int argc, char** argv) {

    map<string,ex> exMap;
    Symbol a("a"), b("b"), c("c");
    
    ex item1 = pow(a+b+c,5);
    ex item2 = log(a+b+ex(1)/5);
    
    exMap["item1"] = item1;
    exMap["key2"] = item2;
    
    hout << "export exMap to out.gar:" << endl;
    garWrite("out.gar", exMap);
    hout << endl;
    
    hout << "$ ls -l ." << endl << "------" << endl;
    system("ls -l .");
    hout << endl;
    
    // read a single item
    ex item1_gar = garRead("out.gar", "item1");
    hout << "item1 from out.gar: " << item1_gar << endl;
    hout << endl;
    
    // read all items to a map
    hout << "read all items: " << endl;
    map<string,ex> oMap;
    garRead("out.gar", oMap);
    for(auto kv : oMap) {
        hout << kv.first << " :> " << kv.second << endl;
    }
    hout << endl;
    
    hout << "one can also use the binary program: garview" << endl;
    hout << "$ garview out.gar" << endl << "------" << endl;
    ostringstream oss;
    oss << "garview out.gar";
    system(oss.str().c_str());
    hout << endl;
    
    return 0;
}
