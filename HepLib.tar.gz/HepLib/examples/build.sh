#!/bin/bash

fn=$(echo $1 | sed 's/\.cpp//')

# use pkg-config
#g++ $(pkg-config --cflags --libs HepLib) -o $fn fn.cpp

# direct use heplib++
heplib++ -o $fn $fn.cpp
