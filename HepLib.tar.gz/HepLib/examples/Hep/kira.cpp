#include "HepLib.h"

using namespace HepLib;
using namespace IBP;

int main() {

    Symbol q1("q1"), p("p"), k("k"), m("m"), s("s");
    
    { // case: q1*q1, q1*p-1
        KIRA kira;
        kira.Internal = lst{ q1 };
        kira.External = lst{ p };
        kira.Replacements = lst{ p*p == m*m };
        
        kira.Propagators = lst{ q1*q1, q1*p-1};
        kira.Integrals.append(lst{1,1});
        kira.Integrals.append(lst{2,2});
        kira.Integrals.append(lst{2,3});
        
        kira.WorkingDir = "IBPdir";
        
        kira.Export();
        kira.Run();
        kira.Import();
        
        cout << "Reduced Rules:" << endl;
        hout << kira.Rules << endl;
        cout << "Master Integrals:" << endl;
        hout << kira.MIntegrals << endl;
        cout << endl;
    }

        
    //system("rm -rf IBPdir");
    
    return 0;
}
