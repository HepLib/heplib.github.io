#include "HepLib.h"

using namespace HepLib;
using namespace IBP;

int main() {

    Symbol q1("q1"), p("p"), m("m");
    
    FIRE fire;
    fire.Internal = lst{ q1 };
    fire.External = lst{ p };
    fire.Replacements = lst{ p*p == m*m };
    
    fire.Propagators = lst{ q1*q1, 2*p*q1-q1*q1};
    fire.Integrals.append(lst{2,1});
    
    fire.WorkingDir = "IBPdir";
    fire.Reduce();
    
    cout << "Reduced Rules:" << endl;
    hout << fire.Rules << endl;
    cout << "Master Integrals:" << endl;
    hout << fire.MasterIntegrals << endl;
    cout << endl;
    
    system("rm -rf IBPdir");
    
    return 0;
}
