#include "HepLib.h"

using namespace std;
using namespace GiNaC;
using namespace HepLib;
using namespace FC;
using namespace Qgraf;
using namespace Quarkonium;

Vector p("p"), q1("q1"), q2("q2");
Symbol m("m");
ex p1 = p, p2 = p;

void TeXOut(const ex & e) {
    ex ee = exfactor(fermat_normal(e));
    stringstream ss;
    HepFormat ho(ss);
    ho << ee;
    string o = ss.str();
    string_replace_all(o,"𝛾","(-@$\\gamma$@-)");
    string_replace_all(o,"𝕚","(-@$\\mathbbm{1}$@-)");
    cout << o << endl << endl;
}

ex Amps();
int main() {
    Verbose = 100;
    
    ex amps;
    if(file_exists("amps.gar")) {
        amps = garRead("amps.gar");
    } else {
        amps = Amps();
        garWrite("amps.gar", amps);
    }
    
    Index mu("mu"), nu("nu");
    
    letSP(p)=m*m;
    letSP(p,nu)=0;
    
    lst extps = lst{ p };
    lst loops = lst{ q1 };
    ex proj = SpinProj(IO::In, 1, p1, p2, m, m, nu, -1, -3) * ColorProj(-1, -3);
    
    auto amp1 = amps.op(1).op(0);
    amp1 = amp1.subs(LI(-2)==mu);
    hout << amp1 << endl << endl;
    //TeXOut(amp1);
    
    amp1 = MatrixContract(amp1);
    hout << amp1 << endl << endl;
    //TeXOut(amp1);
    
    amp1 = amp1 * proj;
    amp1 = MatrixContract(amp1);
    hout << amp1 << endl << endl;
    //TeXOut(amp1);

    form_using_su3 = true;
    amp1 = form(amp1);
    amp1 = amp1.subs(lst{NF==3,D==4-2*ep});
    hout << exfactor(amp1) << endl << endl;
    //TeXOut(amp1);

    amp1 = TIR(amp1, loops, extps);
    amp1 = amp1.subs(lst{NF==3,D==4-2*ep});
    hout << exfactor(amp1) << endl << endl;
    //TeXOut(amp1);
    
    exvector res_vec;
    res_vec.push_back(amp1);
    ApartIBP(1, res_vec, lst{ loops, extps });
    ex res = 0;
    for(auto item : res_vec) res += item.subs(lst{d==4-2*ep,D==4-2*ep});
    ex mi = str2ex("F({q1^2+(-2)*p*q1},{1})"); // copied from last output
    ex miv = -tgamma(-1+ep)*pow(m,2*(1-ep))*I*pow(Pi,2-ep)*pow(2*Pi,2*ep-4);
	res = res.subs(lst{ mi==miv });
	res = mma_series(res,ep,0);

    hout << mma_collect(exfactor(res),ep) << endl;
    
    return 0;
}


// copied from all.cpp

extern string model;
ex Amps() {
    
    Symbol A("A"), Q("Q"), Qbar("Qbar"), q("q"), qbar("qbar"), g("g"), gh("gh"), ghbar("ghbar");
    
    Qgraf::Process proc;
    proc.Model = model;
    proc.In = "Q[p1],Qbar[p2]";
    proc.Out = "A[pA]";
    proc.Options = "onshell";
    proc.LoopPrefix = "q";
    
    symtab st;
    st["pA"] = p1+p2;
    st["p1"] = p1;
    st["p2"] = p2;
    st["q1"] = q1;
    st["q2"] = q2;
    
    proc.Loops = 0;
    auto amp0 = proc.Amplitudes(st);
    proc.Loops = 1;
    auto amp1 = proc.Amplitudes(st);
    proc.Loops = 2;
    auto amp2 = proc.Amplitudes(st);
    
    lst glst;
    lst chk = lst{-1,-3,g};
    chk.sort();
    
    auto filter = [&](lst & ampi)->void {
        auto tmp = ampi;
        ampi.remove_all();
        for(auto amp : tmp) {
            
            auto cps = ShrinkCut(amp, lst{g, g}, 1);
            for(auto cpi : cps) {
                for(auto cpii0 : cpi) {
                    lst cpii = ex_to<lst>(cpii0.subs(lst{-10==g}));
                    cpii.sort();
                    if(cpii==chk) goto amp_done;
                }
            }
            
            ampi.append(amp);
            amp_done: ;
        }
    };
        
    lst amps = lst{ amp0, amp1, amp2 };
    cout << "Process Filter: [ ";
    for(auto amp : amps) cout << amp.nops() << " ";
    cout << "] :> ";
    
    filter(amp0);
    filter(amp1);
    filter(amp2);
    
    amps = lst{ amp0, amp1, amp2 };
    cout << "[ ";
    for(auto amp : amps) cout << amp.nops() << " ";
    cout << "]" << endl;
    
    // generate diagrams to pdf
    if(false) {
        LineTeX[A] = "photon";
        InOutTeX[-1]="$Q$";
        InOutTeX[-3]="$\\bar{Q}$";
        InOutTeX[-2]="$\\gamma^*$";
        DrawPDF(amp0, "amp0.pdf");
        DrawPDF(amp1, "amp1.pdf");
        DrawPDF(amp2, "amp2.pdf");
    }

    // feynman rules here
    auto map = MapFunction([&](const ex &e, MapFunction &self)->ex {
        if(isFunction(e,"OutField") || isFunction(e,"InField")) return 1;
        else if(isFunction(e, "Propagator")) {
            if(e.op(0).op(0)==q) {
                return QuarkPropagator(e, 0);
            } else if(e.op(0).op(0)==Q) {
                return QuarkPropagator(e, m);
            } else if(e.op(0).op(0)==g) {
                return GluonPropagator(e);
            } else if(e.op(0).op(0)==gh) {
                return GhostPropagator(e);
            }
        } else if(isFunction(e, "Vertex")) {
            if(e.nops()==3 && e.op(0).op(0)==ghbar && e.op(1).op(0)==gh) {
                // ghbar-gh-g
                return gh2gVertex(e);
            } else if(e.nops()==3 && e.op(0).op(0)==g && e.op(1).op(0)==g && e.op(2).op(0)==g) {
                // g^3
                return g3Vertex(e);
            } else if(e.nops()==4 && e.op(0).op(0)==g && e.op(1).op(0)==g && e.op(2).op(0)==g && e.op(3).op(0)==g) {
                // g^4
                return g4Vertex(e);
            } else if(e.nops()==3 && ((e.op(0).op(0)==qbar && e.op(1).op(0)==q) || (e.op(0).op(0)==Qbar && e.op(1).op(0)==Q)) ) {
                // qbar-q-g or Qbar-Q-g or g -> e
                if(e.op(2).op(0)==g) return q2gVertex(e);
                else {
                    auto fi1 = e.op(0).op(1);
                    auto fi2 = e.op(1).op(1);
                    auto fi3 = e.op(2).op(1);
                    return Matrix(GAS(LI(fi3)),DI(fi1),DI(fi2)) * SP(TI(fi1),TI(fi2));
                }
            }
        }
        return e.map(self);
    });

    amp0 = ex_to<lst>(map(amp0));
    amp1 = ex_to<lst>(map(amp1));
    amp2 = ex_to<lst>(map(amp2));
    
    return lst { amp0, amp1, amp2 };
}

std::string model = R"EOF(
[ model = 'eqcd Model' ]
%------------------------------------
% Propagators
%------------------------------------
[q, qbar, -]
[Q, Qbar, -]
[gh, ghbar, -]
[g, g, +, notadpole]
[A, A, +, external]
%------------------------------------
% Vertices
%------------------------------------
[qbar, q, g; QCD='+1']
[Qbar, Q, g; QCD='+1']
[g, g, g, g; QCD='+2']
[g, g, g; QCD='+1']
[ghbar, gh, g; QCD='+1']
[qbar, q, A; QCD='+0']
[Qbar, Q, A; QCD='+0']
)EOF";
