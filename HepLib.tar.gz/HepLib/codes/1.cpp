#include "HepLib.h"
using namespace HepLib;
using namespace std;
int main(int argc, char** argv) {
    Parser parser;
    string expr_str = "WF(1)+x(1)^2+sin(5)+power(a,n)"; 
    ex e1 = parser.Read(expr_str);
    hout << e1 << endl;
    Symbol a("a"), n("n");
    ex e2 = WF(1)+pow(x(1),2)+GiNaC::sin(5)+pow(a,n);
    hout << e1-e2 << endl;
    return 0;
}
