#include "HepLib.h"
using namespace HepLib;
using namespace FC;
int main(int argc, char** argv) {
    Parser parser;
    string expr_str = "WF(1)+x(1)^2+sin(5)+power(a,n)"; 
    ex e1 = parser.Read(expr_str);
    cout << e1 << endl;
    Symbol a("a"), n("n");
    ex e2 = WF(1)+pow(x(1),2)+sin(5)+pow(a,n);
	cout << e1-e2 << endl;
    return 0;
}
