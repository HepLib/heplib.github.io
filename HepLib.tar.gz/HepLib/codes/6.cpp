#include "HepLib.h"
using namespace HepLib;
using namespace QGRAF;

extern string model;
int main(int argc, char** argv) {
    
    Symbol A("A"), e("e"), ebar("ebar"), mu("mu"), mubar("mubar");
    Vector p("p"), P("P"), k("k"), K("K");
    Symbol me("me"), mm("mm");
    
    Process proc;
    proc.Model = R"EOF(
        [e, ebar, -]
        [mu, mubar, -]
        [A, A, +]
        [ebar, e, A]
        [mubar, mu, A]
        )EOF";
    proc.In = "e[p],ebar[P]";
    proc.Out = "mubar[k],mu[K]";
    proc.Options = "onshell";
    proc.Loops = 0;
    
    symtab st;
    st["p"] = p;
    st["P"] = P;
    st["k"] = k;
    st["K"] = K;
    
    auto amps = proc.Amplitudes(st);
    
    hout << "amps:" << endl << ex(amps) << endl << endl;
        
    // generate diagrams to pdf
    InOutTeX[-1]="$e^-(p)$";
    InOutTeX[-3]="$e^+(P)$";
    InOutTeX[-2]="$\\mu^+(k)$";
    InOutTeX[-4]="$\\mu^-(K)$";
    
    LineTeX[e] = "fermion, edge label=$e$";
    LineTeX[ebar] = "anti fermion, edge label=$e$";
    LineTeX[mu] = "fermion, edge label=$\\mu$";
    LineTeX[mubar] = "anti fermion, edge label=$\\mu$";
    LineTeX[A] = "photon, edge label=$\\gamma$";
    
    DrawPDF(amps, "amps.pdf");
        
    // feynman rules here
    auto amps_feyn_rule = MapFunction([&](const ex &e, MapFunction &self)->ex {
        if(isFunction(e,"OutField") || isFunction(e,"InField")) return 1;
        else if(isFunction(e, "Propagator")) {
            auto fi1 = e.op(0).op(1);
            auto fi2 = e.op(1).op(1);
            auto mom = e.op(2);
            if(e.op(0).op(0)==A) {
                return (-I) * SP(LI(fi1),LI(fi2)) / SP(mom); // Feynman Gauge
            } else if(e.op(0).op(0)==ebar) {
                return I * Matrix(GAS(mom)+GAS(1)*me, DI(fi1),DI(fi2)) / (SP(mom)-me*me);
            } else if(e.op(0).op(0)==mubar) {
                return I * Matrix(GAS(mom)+GAS(1)*mm, DI(fi1),DI(fi2)) / (SP(mom)-mm*mm);
            }
        } else if(isFunction(e, "Vertex")) {
            auto fi1 = e.op(0).op(1);
            auto fi2 = e.op(1).op(1);
            auto fi3 = e.op(2).op(1);
            if(e.op(0).op(0)==ebar) {
                return I*Symbol("e")*Matrix(GAS(LI(fi3)),DI(fi1),DI(fi2));
            } else if(e.op(0).op(0)==mubar) {
                return I*Symbol("e")*Matrix(GAS(LI(fi3)),DI(fi1),DI(fi2));
            }
        }
        return e.map(self);
    })(amps);
    
    hout << "amps_feyn_rule:" << endl << amps_feyn_rule << endl << endl;
    
    ex ampL = amps_feyn_rule.op(0);
    ex ampR = IndexL2R(conjugate(ampL));
    #define SS1(p,m,i) Matrix(GAS(p)+m*GAS(1),DI(i),RDI(i))
    #define SS2(p,m,i) Matrix(GAS(p)+m*GAS(1),RDI(i),DI(i))
    ex M2 = ampL * ampR * SS1(p,me,-1) * SS2(P,-me,-3) * SS1(k,-mm,-2) * SS2(K,mm,-4);
    M2 = MatrixContract(M2);
    
    hout << "M2:" << endl << M2 << endl << endl;
    
    form_using_dim4 = true;
    letSP(p)=me*me; letSP(P)=me*me;
	letSP(k)=mm*mm; letSP(K)=mm*mm;
    auto res = form(M2);
    hout << "Final M2:" << endl << exfactor(res.subs(me==0)) << endl;
    
    return 0;
}
