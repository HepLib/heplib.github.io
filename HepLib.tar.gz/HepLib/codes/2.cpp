#include "HepLib.h"
using namespace HepLib;
int main(int argc, char** argv) {
    Symbol x("x"), y("y"), z("z"), n("n");
    lst l1 = lst{ x, y, x+z };
    ex e1 = pow(sin(x),n);
    hout << "l1 -> " << l1 << endl;
    hout << "e1 -> " << e1 << endl;
    int tot = l1.nops(); // tot is 3
    hout << "l1.nops() -> " << tot << endl;
    ex item1 = l1.op(0); // 1st item in l1, --> x
    hout << "1st item of l1 -> " << item1 << endl;
    l1.let_op(2) = e1; // now l1 is {x, y, sin(x)^n}
    hout << "updated l1 -> " << l1 << endl;
    tot = e1.nops(); // now tot is 2
    hout << "e1.nops() -> " << tot << endl;
    ex item2 = e1.op(1); // 2nd item in e1, --> n
    hout << "2nd item of e1 -> " << item2 << endl;
    return 0;
}
