#include "HepLib.h"
using namespace HepLib;
int main(int argc, char** argv) {
    Symbol x("x"), y("y");
    ex e0 = str2ex("x^4+x^3+x^2+x"); //HepLib::str2ex: convert string text to an expression, using Parser internally
    hout << "e0 -> " << e0 << endl;
    ex e1 = e0.subs(lst{pow(x,w)==pow(y,w+2)});
    hout << "e1 -> " << e1 << endl;
    
    MapFunction map([&](const ex &e, MapFunction self)->ex {
        if(e.match(pow(x,w)) && e.op(1).info(info_flags::even)) return pow(y,e.op(1)+2);
        else return e.map(self); 
    });
    ex e2 = map(e0);
    hout << "e2 -> " << e2 << endl;
    return 0;
}
