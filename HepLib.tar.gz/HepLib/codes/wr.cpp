#include "HepLib.h"

using namespace HepLib;
using namespace SD;

int main() {
    
    ex wra = WRA(Pi/5);
    XIntegrand xint;
    xint.Functions = lst{1,-4*x(4)*x(4)-12*x(1)*x(4)+x(1)*x(2),x(1),x(2)};
    xint.Exponents = lst{1,1/ex(2)-2*ep,3*ep-5/ex(2),ep-3/ex(2)};
    xint.Deltas = lst{lst{x(1),x(2),x(4)}};
    
    xint.Functions = ex_to<lst>(subs(xint.Functions,{x(4)==x(4)*exp(I*wra)}));
    xint.Functions.let_op(0) = exp(I*wra);

    SecDec work;
    work.epN = 1;
    Verbose = 100;
    
    work.Initialize(xint);
    work.RemoveDeltas();
    work.SDPrepares();
    work.EpsEpExpands();
    work.CIPrepares();
    
    work.EpsAbs = 1E-5;
    work.RunPTS = 1000000;
    work.RunMAX = 5;
                
    auto intor = new HCubature();
    intor->MPXLimit = 1E-5;
    intor->QXLimit = 1E-2;
    work.Integrator = intor;
    work.Integrates();
    
    cout << VEResult(work.ResultError) << endl;
    
    
    return 0;
}
