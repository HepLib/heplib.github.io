#include "HepLib.h"
using namespace HepLib;
int main(int argc, char** argv) {
    Symbol x("x"), y("y");
    vector<ex> foo_vec;
    int total = 1000;
    for(int i=0; i<total; i++) foo_vec.push_back(sin(exp(x+y*i)));
    Verbose = 100;
    vector<ex> ret = GiNaC_Parallel(total, [&](int idx)->ex {
        ex data = foo_vec[idx];
        data = series_ex(data,x,5);
        return data;
    });
    //hout << ret << endl;
    return 0;
}
