#include "HepLib.h"
using namespace HepLib;
int main(int argc, char** argv) {

//section 1
{
    symbol x("x"), y("y"), z("z"); //complex variables
    numeric r(2,3); //exact fraction 2/3
    hout << "x -> " << x << ", r->" << r << endl;
    ex e1 = r*x+2*y+pow(y,10); //polynomial in x and y
    hout << "e1 -> " << e1 << endl;
    ex e2 = (x+1)/(x-1); //rational expression
    hout << "e2 -> " << e2 << endl;
    ex e3 = sin(x+2*y)+3*z+41; //containing a function
    hout << "e3 -> " << e3 << endl;
    ex e4 = e3+e2/exp(e1); //expression formed from other expressions
    hout << "e4 -> " << e4 << endl;
}

hout << endl;

//section 2
{
    symbol x("x"); //a complex variable
    Symbol y("y"); //a real variable
    hout << "x -> " << x << ", y->" << y << endl;
    ex e1 = conjugate(x); //complex conjugation of x --> conjugate(x)
    hout << "conjugate(x) -> " << e1 << endl;
    ex e2 = conjugate(y); //complex conjugation of y --> y
    hout << "conjugate(y) -> " << e2 << endl;
}
    return 0;
}
