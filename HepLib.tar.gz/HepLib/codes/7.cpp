#include "HepLib.h"
using namespace HepLib;
using namespace FC;

extern string model;
int main(int argc, char** argv) {
    
    Vector p("p"), q1("q1");
    ex expr = 1/SP(q1) * 1/(2*SP(p,q1)-SP(q1)) * 1/(2*SP(p,q1)+SP(q1));
    ex r = Apart(expr,lst{q1},lst{p});
    ex r1 = ApartIR2ex(r);
    ex r2 = ApartIR2F(r);
    hout << r << endl << endl;
    hout << r1 << endl << endl;
    hout << r2 << endl << endl;
    
    ex r3 = Apart(expr, lst{SP(q1),SP(p,q1)});
    hout << r3 << endl << endl;
    
    return 0;
}
