#include "HepLib.h"
using namespace HepLib;
using namespace FC;
int main(int argc, char** argv) {
    Symbol me("me"), mm("mm"), e("e");
	Index mu("mu"), nu("nu");
	Vector p("p"), P("P"), k("k"), K("K"), q("q");
	letSP(p)=me*me; letSP(P)=me*me;
	letSP(k)=mm*mm; letSP(K)=mm*mm;
	#define gpm(p,m) (GAS(p)+m*GAS(1))
	ex tr1 = TR( gpm(P,-me)*GAS(mu)*gpm(p,me)*GAS(nu) );
	ex tr2 = TR( gpm(k,mm)*GAS(mu)*gpm(K,-mm)*GAS(nu) );
	ex res =  pow(e,4) / (4*pow(SP(q),2)) * tr1 * tr2;
    form_using_dim4 = true;
	res = form(res);
    res = exfactor(res);
	hout << res << endl;
    hout << res.subs(me==0) << endl;
    
    form_using_su3 = true;
    Index a("a",Index::Type::CA), i("i",Index::Type::CF), j("j",Index::Type::CF);
    ex tr = TTR(lst{a,a});
    cout << "tr1 = " << form(tr) << endl;
    tr = SUNT(a,i,j) * SUNT(a,j,i);
    cout << "tr2 = " << form(tr) << endl;
    tr = SUNT(lst{a,a},i,i);
    cout << "tr3 = " << form(tr) << endl;
    return 0;
}
