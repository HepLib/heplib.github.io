extern "C" {
    #include <libqhull_r/qhull_ra.h>
}
#include "HepLib.h"

int main() {
    qhT qh_qh;
    qhT *qh= &qh_qh;
    int npts = 30;
    int dim = 5;
    coordT cpts[30*5] ={1,1,1,2,0,0,0,2,2,1,0,1,2,2,0,0,1,1,2,1,0,2,1,0,2,1,0,2,0,2,1,1,1,0,2,0,0,2,1,2,1,2,0,2,0,0,2,0,0,2,0,0,2,2,0,0,2,0,2,1,0,1,1,1,2,0,2,0,2,0,0,2,1,1,1,0,0,2,0,2,0,1,1,2,0,1,0,2,1,1,0,2,0,1,2,0,1,2,0,2,0,1,1,1,1,1,0,2,2,0,0,2,1,2,0,0,2,0,1,1,1,2,0,0,2,0,0,2,1,1,1,2,0,1,1,1,1,1,1,1,0,1,2,1,1,0,1,1,0,2};

    char opts[32];
    sprintf(opts, "qhull Fv");
    FILE* dev_null = fopen("/dev/null", "w");
    int curlong, totlong;
    boolT ismalloc = false;
    qh_zero(qh, dev_null);
    int exit_code = qh_new_qhull(qh, dim, npts, cpts, ismalloc, opts, NULL, dev_null);
    printf("\n%d vertices and %d facets with normals:\n",
                 qh->num_vertices, qh->num_facets);
                
    //std::vector<std::vector<int>> ret;
    facetT *facet;
    vertexT *vertex, **vertexp;
    FORALLfacets {
        //std::vector<int> lvec;
        FOREACHvertex_(facet->vertices) {
            //lvec.push_back(qh_pointid(qh, vertex->point));
            printf("%d, ",qh_pointid(qh, vertex->point));
        }
        //ret.push_back(lvec);
        
    }
    //cout << ret.size() << endl;    
    
    return 0;
}
